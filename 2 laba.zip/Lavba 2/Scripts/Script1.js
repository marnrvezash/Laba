// Данные для карточек "Путеводитель по России"
const guideCardsData = [
    {
        image: 'гастроном2.jpg',
        text: 'Тумба под телевизор'
    },
    {
        image: 'народы2.jpg',
        text: ''
    },
    {
        image: 'лечебное2.jpg',
        text: ''
    },
    {
        image: 'развлечения4.jpg',
        text: ''
    },
    {
        image: 'active2.jpg',
        text: ''
    },
    {
        image: 'театр2.jpg',
        text: ''
    }
];

// Данные для шагов процесса
const processSteps = [

];

// Данные для статистики
const statistics = [
    { number: '1 год', text: 'гарантия на всю продукцию' },
    { number: '300+', text: 'реализованных проектов' },
    { number: '15 дней', text: 'срок производства' }
];

// Функция создания раздела "Путеводитель по России"
function createRussiaGuideSection() {
    const section = document.createElement('div');
    section.className = 'russia-guide-section';
    
    section.innerHTML = `
        <div class="titt">
            <div id="contr"></div>
            <h1><b>Проекты</b></h1>
        </div>
        <div class="pict">
            ${guideCardsData.map(card => `
                <div class="pict_item">
                    <img class="pict_photo" src="${card.image}" alt="${card.title}">
                    <div class="pict_content">
                        <div class="pict_text">${card.text}</div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
    
    return section;
}

// Функция создания шагов процесса
function createProcessSteps() {
    const processContainer = document.createElement('div');
    processContainer.className = 'process-steps';
    
    processContainer.innerHTML = processSteps.map(step => `
        <div class="step">
            <h3>${step.title}</h3>
            <p>${step.description}</p>
        </div>
    `).join('');
    
    const processSection = document.getElementById('process');
    if (processSection) {
        const container = processSection.querySelector('.container');
        if (container) {
            container.appendChild(processContainer);
        }
    }
}

// Функция создания статистики
function createStatistics() {
    const statsContainer = document.createElement('div');
    statsContainer.className = 'stats';
    
    statsContainer.innerHTML = statistics.map(stat => `
        <div class="stat-item">
            <div class="stat-number">${stat.number}</div>
            <div>${stat.text}</div>
        </div>
    `).join('');
    
    const aboutSection = document.getElementById('about-section');
    if (aboutSection) {
        const aboutContent = aboutSection.querySelector('.about-content');
        if (aboutContent && aboutContent.children.length > 1) {
            const secondColumn = aboutContent.children[1];
            secondColumn.appendChild(statsContainer);
        }
    }
}

// Функция для добавления раздела на страницу
function addRussiaGuide() {
    const guideSection = createRussiaGuideSection();
    const processSection = document.getElementById('process');
    
    if (processSection) {
        processSection.insertAdjacentElement('afterend', guideSection);
    }
}

// Функция для обработки форм (без кнопки заказа проекта)
function initFormHandlers() {
    // Обработчик для формы обратной связи
    const feedbackForm = document.getElementById('form_input');
    if (feedbackForm) {
        const sendButton = document.getElementById('mess_send');
        if (sendButton) {
            sendButton.addEventListener('click', function() {
                const name = document.getElementById('name').value;
                const email = document.getElementById('email').value;
                const message = document.getElementById('message').value;
                
                if (name && email && message) {
                    feedbackForm.reset();
                }
            });
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Создаем все динамические элементы
    addRussiaGuide();        // Раздел "Путеводитель по России"
    createProcessSteps();    // Шаги процесса
    createStatistics();      // Статистика
    
    // Инициализируем обработчики событий
    initFormHandlers();      // Формы
});