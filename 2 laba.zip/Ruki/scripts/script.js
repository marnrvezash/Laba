const Clock = {
    state: {
        usingRealTime: true,    /* исп реал времени */
        userOffset: 0
    },

    elements: {     /* ссылки на все html */
        container: document.querySelector('.clock-container'),
        settingsBtn: document.querySelector('.settings-btn'),
        timeDisplay: document.getElementById('timeDisplay'),
        dayOfWeek: document.getElementById('dayOfWeek'),
        date: document.getElementById('date'),
        popup: document.getElementById('settingsPopup'),
        indicators: {
            minutes: document.getElementById('minutesIndicator'),
            seconds: document.getElementById('secondsIndicator')
        },
        inputs: {
            dateTime: document.getElementById('setDateTime')
        },
        buttons: {
            cancel: document.querySelector('.btn-cancel'),
            real: document.querySelector('.btn-real'),
            check: document.querySelector('.btn-check')
        }
    },

    data: {
    
        days: ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'],
        months: ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
                 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря']
    },

    digitImages: {
        0: 'images/0.png',
        1: 'images/1.png',
        2: 'images/2.png',
        3: 'images/3.png',
        4: 'images/4.png',
        5: 'images/5.png',
        6: 'images/6.png',
        7: 'images/7.png',
        8: 'images/8.png',
        9: 'images/9.png'
    },

    init() {
        this.createDigits();
        this.bindEvents();
        this.update();
        setInterval(() => this.update(), 1000);
        this.initBlink();
    },

    createDigits() {
        const parts = ['h1', 'h2', ':', 'm1', 'm2', ':', 's1', 's2'];
        this.digitElements = {};

        parts.forEach(part => {
            if (part === ':') {
                const sep = document.createElement('div');
                sep.className = 'separator';
                sep.textContent = ':';
                this.elements.timeDisplay.appendChild(sep);
            } else {
                const digitContainer = document.createElement('div');
                digitContainer.className = 'digit';
                const img = document.createElement('img');
                img.alt = part;
                img.src = this.digitImages[0];
                digitContainer.appendChild(img);
                this.elements.timeDisplay.appendChild(digitContainer);
                this.digitElements[part] = img;
            }
        });
    },

    update() {
        const now = this.state.usingRealTime 
            ? new Date() 
            : new Date(Date.now() + this.state.userOffset);

        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');

        this.digitElements.h1.src = this.digitImages[hours[0]];
        this.digitElements.h2.src = this.digitImages[hours[1]];
        this.digitElements.m1.src = this.digitImages[minutes[0]];
        this.digitElements.m2.src = this.digitImages[minutes[1]];
        this.digitElements.s1.src = this.digitImages[seconds[0]];
        this.digitElements.s2.src = this.digitImages[seconds[1]];

        this.elements.dayOfWeek.textContent = this.data.days[now.getDay()];
        this.elements.date.textContent = `${now.getDate()} ${this.data.months[now.getMonth()]} ${now.getFullYear()}`;

        const minProgress = now.getSeconds() / 60;
        const secProgress = now.getSeconds() / 60;

        this.elements.indicators.minutes.style.transform = `scaleX(${minProgress})`;
        this.elements.indicators.seconds.style.transform = `scaleX(${secProgress})`;
    },

    initBlink() {
        setInterval(() => {
            const separators = this.elements.timeDisplay.querySelectorAll('.separator');
            separators.forEach(sep => {
                sep.style.opacity = sep.style.opacity === '0.2' ? '0.7' : '0.2';
            });
        }, 500);
    },

    bindEvents() {
        const e = this.elements;
        e.settingsBtn.addEventListener('click', () => this.openSettings());
        e.buttons.cancel.addEventListener('click', () => this.closePopup());
        e.buttons.real.addEventListener('click', () => this.useRealTime());
        e.buttons.check.addEventListener('click', () => this.saveAndLog());
    },

    openSettings() {
        const now = this.state.usingRealTime 
            ? new Date() 
            : new Date(Date.now() + this.state.userOffset);

        const formatted = now.getFullYear() + '-' +
            (now.getMonth() + 1).toString().padStart(2, '0') + '-' +
            now.getDate().toString().padStart(2, '0') + ' ' +
            now.getHours().toString().padStart(2, '0') + ':' +
            now.getMinutes().toString().padStart(2, '0') + ':' +
            now.getSeconds().toString().padStart(2, '0');

        this.elements.inputs.dateTime.value = formatted;
        this.elements.popup.style.display = 'flex';
    },

    closePopup() {
        this.elements.popup.style.display = 'none';
    },

    useRealTime() {
        this.state.usingRealTime = true;
        this.state.userOffset = 0;
        this.update();
        this.closePopup();
    },

    saveAndLog() {
        const input = this.elements.inputs.dateTime.value.trim();
        const now = new Date();

        const regex = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
        if (!regex.test(input)) {
            alert('Неверный формат!\nИспользуйте: ГГГГ-ММ-ДД ЧЧ:ММ:СС');
            return;
        }

        const customDate = new Date(input);
        if (isNaN(customDate.getTime())) {
            alert('Неверная дата!');
            return;
        }

        this.state.userOffset = customDate.getTime() - now.getTime();
        this.state.usingRealTime = false;
        this.update();

        // Вывод в консоль с миллисекундами
        const fullDate = new Date(Date.now() + this.state.userOffset);
        console.log('Установлено время:', fullDate.toISOString());

        this.closePopup();
    }
};

document.addEventListener('DOMContentLoaded', () => {
    Clock.init();
});
